CREATE VIEW user_view as
select userid, username, firstname, lastname, phone from users;

