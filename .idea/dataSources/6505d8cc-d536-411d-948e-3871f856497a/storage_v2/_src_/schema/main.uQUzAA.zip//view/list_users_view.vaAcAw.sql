CREATE VIEW list_users_view as
select *
from user_view
         inner join list_users lu on user_view.userid = lu.userid;

